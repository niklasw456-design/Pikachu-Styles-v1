package de.texturemixer;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

/** Findet Texturepacks im resourcepacks-Ordner und baut daraus das Ausgabe-Pack. */
public final class PackScanner {
    public static final String OUTPUT_NAME = "texturemixer_output";

    private static final String MCMETA = """
            {
              "pack": {
                "description": "Pikachu Styles (automatisch erzeugt)",
                "pack_format": 75,
                "supported_formats": { "min_inclusive": 34, "max_inclusive": 75 }
              }
            }
            """;

    /** categories enthält die Variant-IDs (siehe Category.fullId), die das Pack unterstützt. */
    public record PackInfo(String name, Path path, Set<String> categories) {}

    /**
     * Rohdaten für das Vorschaubild: entweder PNG (+ optional .mcmeta für Animation)
     * oder fertige ARGB-Pixel (argb != null), z. B. bei Tränken.
     */
    public record PreviewData(byte[] png, byte[] mcmeta, int[] argb, int w, int h) {}

    private interface RootAction<T> {
        T run(Path root) throws IOException;
    }

    private PackScanner() {}

    public static Path packsDir() {
        return FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
    }

    public static List<PackInfo> scan() {
        List<PackInfo> result = new ArrayList<>();
        Path dir = packsDir();
        if (!Files.isDirectory(dir)) return result;

        List<Path> entries;
        try (Stream<Path> s = Files.list(dir)) {
            entries = s.sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase())).toList();
        } catch (IOException e) {
            TextureMixerClient.LOGGER.warn("resourcepacks-Ordner nicht lesbar", e);
            return result;
        }

        for (Path p : entries) {
            String name = p.getFileName().toString();
            if (name.equals(OUTPUT_NAME)) continue;
            boolean zip = Files.isRegularFile(p) && name.toLowerCase().endsWith(".zip");
            boolean folder = Files.isDirectory(p);
            if (!zip && !folder) continue;
            try {
                Set<String> cats = withRoot(p, PackScanner::detect);
                result.add(new PackInfo(name, p, cats));
            } catch (Exception e) {
                TextureMixerClient.LOGGER.warn("Pack {} konnte nicht gelesen werden", name, e);
            }
        }
        return result;
    }

    /** Baut das Ausgabe-Pack. Gibt die Anzahl erzeugter Einträge zurück (0 = Pack wurde entfernt). */
    public static int buildOutput(Map<String, String> selections, List<PackInfo> packs) throws IOException {
        Path out = packsDir().resolve(OUTPUT_NAME);
        deleteOutput(out);

        Path mc = out.resolve("assets").resolve("minecraft");
        int count = 0;
        Map<String, List<PotionSupport.Case>> potionCases = new LinkedHashMap<>();

        for (Category c : Category.ALL) {
            for (Category.Variant v : c.variants()) {
                String sel = selections.get(c.fullId(v));
                if (sel == null) continue;
                PackInfo info = packs.stream().filter(p -> p.name().equals(sel)).findFirst().orElse(null);
                if (info == null) continue;
                Files.createDirectories(mc);

                if (v.potion() != null) {
                    Category.PotionSpec ps = v.potion();
                    String key = (c.id() + "_" + v.key()).replaceAll("[^a-z0-9_]", "_");
                    PotionSupport.Case cs = withRoot(info.path(), root -> {
                        Map<String, Object> node = PotionSupport.resolveFor(root, ps.itemDef(), ps.ids());
                        if (node == null) return null;
                        return new PotionSupport.Case(ps.ids(), PotionSupport.export(root, node, mc, key));
                    });
                    if (cs != null) potionCases.computeIfAbsent(ps.itemDef(), k -> new ArrayList<>()).add(cs);
                    continue;
                }
                count += withRoot(info.path(), root -> copyVariant(root, v, mc));
            }
        }

        // Tränke: eine gemeinsame Weiche pro Item (potion / splash_potion), alle anderen Tränke bleiben Vanilla
        for (Map.Entry<String, List<PotionSupport.Case>> e : potionCases.entrySet()) {
            Object vanilla = vanillaModel(e.getKey());
            if (vanilla == null) {
                TextureMixerClient.LOGGER.warn("Vanilla-Definition für {} nicht gefunden, Trank-Texturen übersprungen", e.getKey());
                continue;
            }
            List<Object> cases = new ArrayList<>();
            for (PotionSupport.Case cs : e.getValue()) {
                Map<String, Object> cm = new LinkedHashMap<>();
                cm.put("when", new ArrayList<Object>(cs.ids()));
                cm.put("model", cs.node());
                cases.add(cm);
            }
            Map<String, Object> sel = new LinkedHashMap<>();
            sel.put("type", "minecraft:select");
            sel.put("property", "minecraft:component");
            sel.put("component", "minecraft:potion_contents");
            sel.put("cases", cases);
            sel.put("fallback", vanilla);
            Map<String, Object> top = new LinkedHashMap<>();
            top.put("model", sel);
            Path items = mc.resolve("items").resolve(e.getKey() + ".json");
            Files.createDirectories(items.getParent());
            Files.writeString(items, Json.write(top));
            count++;
        }

        if (count == 0) {
            deleteOutput(out);
            return 0;
        }
        Files.writeString(out.resolve("pack.mcmeta"), MCMETA);
        return count;
    }

    /** Liest die originale Item-Definition aus dem Spiel selbst (unabhängig von Resource Packs). */
    @SuppressWarnings("unchecked")
    private static Object vanillaModel(String itemDef) {
        try {
            Optional<ModContainer> container = FabricLoader.getInstance().getModContainer("minecraft");
            if (container.isEmpty()) return null;
            Optional<Path> p = container.get().findPath("assets/minecraft/items/" + itemDef + ".json");
            if (p.isEmpty()) return null;
            Object parsed = Json.parse(Files.readString(p.get()));
            return parsed instanceof Map<?, ?> m ? ((Map<String, Object>) m).get("model") : null;
        } catch (Exception e) {
            TextureMixerClient.LOGGER.warn("Vanilla-Definition konnte nicht gelesen werden", e);
            return null;
        }
    }

    /** Liest das Vorschaubild einer Variante aus einem Pack. */
    public static PreviewData readPreview(PackInfo pack, Category.Variant v) throws IOException {
        if (v.potion() != null) {
            Category.PotionSpec ps = v.potion();
            return withRoot(pack.path(), root -> {
                Map<String, Object> node = PotionSupport.resolveFor(root, ps.itemDef(), ps.ids());
                if (node == null) return null;
                PotionSupport.Image img = PotionSupport.preview(root, node, ps.color());
                if (img == null) return null;
                return new PreviewData(null, null, img.argb(), img.w(), img.h());
            });
        }
        return withRoot(pack.path(), root -> {
            Path tex = textures(root);
            if (!Files.isDirectory(tex)) return null;
            Path file = null;
            for (String cand : v.previews()) {
                Path p = tex.resolve(cand);
                if (Files.isRegularFile(p)) {
                    file = p;
                    break;
                }
            }
            if (file == null && v.hand() == null) {
                List<Path> files;
                try (Stream<Path> s = Files.walk(tex)) {
                    files = s.filter(Files::isRegularFile).sorted().toList();
                }
                for (Path f : files) {
                    String rel = rel(tex, f);
                    if (rel.endsWith(".png") && v.matches(rel)) {
                        file = f;
                        break;
                    }
                }
            }
            if (file == null) return null;
            byte[] png = Files.readAllBytes(file);
            Path meta = file.resolveSibling(file.getFileName().toString() + ".mcmeta");
            byte[] mcmeta = Files.isRegularFile(meta) ? Files.readAllBytes(meta) : null;
            return new PreviewData(png, mcmeta, null, 0, 0);
        });
    }

    private static Set<String> detect(Path root) throws IOException {
        Set<String> found = new LinkedHashSet<>();
        Path tex = textures(root);
        List<String> rels = new ArrayList<>();
        if (Files.isDirectory(tex)) {
            try (Stream<Path> s = Files.walk(tex)) {
                for (Path p : s.filter(Files::isRegularFile).toList()) rels.add(rel(tex, p));
            }
        }
        Set<String> relSet = new HashSet<>(rels);

        for (Category c : Category.ALL) {
            for (Category.Variant v : c.variants()) {
                boolean ok = false;
                if (v.potion() != null) {
                    ok = PotionSupport.resolveFor(root, v.potion().itemDef(), v.potion().ids()) != null;
                } else if (v.hand() != null) {
                    for (String s : v.hand().sources()) {
                        if (relSet.contains(s)) {
                            ok = true;
                            break;
                        }
                    }
                } else {
                    for (String rel : rels) {
                        if (v.matches(rel)) {
                            ok = true;
                            break;
                        }
                    }
                }
                if (ok) found.add(c.fullId(v));
            }
        }
        return found;
    }

    private static int copyVariant(Path root, Category.Variant v, Path mc) throws IOException {
        Path tex = textures(root);
        if (!Files.isDirectory(tex)) return 0;
        Path outTex = mc.resolve("textures");

        // In der Hand bei Blöcken/Netzen: Textur + eigenes Item-Modell + Item-Definition erzeugen
        if (v.hand() != null) {
            Category.HandSpec h = v.hand();
            for (String s : h.sources()) {
                Path src = tex.resolve(s);
                if (!Files.isRegularFile(src)) continue;

                String texName = "item/texturemixer/" + h.itemId() + "_hand";
                Path dstPng = outTex.resolve(texName + ".png");
                Files.createDirectories(dstPng.getParent());
                Files.copy(src, dstPng, StandardCopyOption.REPLACE_EXISTING);
                Path meta = src.resolveSibling(src.getFileName().toString() + ".mcmeta");
                if (Files.isRegularFile(meta)) {
                    Files.copy(meta, outTex.resolve(texName + ".png.mcmeta"), StandardCopyOption.REPLACE_EXISTING);
                }

                String modelId = "minecraft:item/texturemixer/" + h.itemId() + "_hand";
                String parent = h.cube() ? "minecraft:block/cube_all" : "minecraft:item/generated";
                String key = h.cube() ? "all" : "layer0";
                Path model = mc.resolve("models").resolve("item").resolve("texturemixer")
                        .resolve(h.itemId() + "_hand.json");
                Files.createDirectories(model.getParent());
                Files.writeString(model, "{\"parent\":\"" + parent + "\",\"textures\":{\"" + key + "\":\"" + modelId + "\"}}");

                Path items = mc.resolve("items").resolve(h.itemId() + ".json");
                Files.createDirectories(items.getParent());
                Files.writeString(items, "{\"model\":{\"type\":\"minecraft:model\",\"model\":\"" + modelId + "\"}}");
                return 1;
            }
            return 0;
        }

        List<Path> files;
        try (Stream<Path> s = Files.walk(tex)) {
            files = s.filter(Files::isRegularFile).toList();
        }
        int n = 0;
        for (Category.Rule r : v.rules()) {
            for (Path p : files) {
                String rel = rel(tex, p);
                if (!rel.startsWith(r.src())) continue;
                Path target = outTex.resolve(r.dst() + rel.substring(r.src().length()));
                Files.createDirectories(target.getParent());
                Files.copy(p, target, StandardCopyOption.REPLACE_EXISTING);
                n++;
            }
        }
        return n;
    }

    private static Path textures(Path root) {
        return root.resolve("assets").resolve("minecraft").resolve("textures");
    }

    private static String rel(Path base, Path p) {
        return base.relativize(p).toString().replace('\\', '/');
    }

    private static <T> T withRoot(Path pack, RootAction<T> action) throws IOException {
        if (Files.isDirectory(pack)) return action.run(pack);
        try (FileSystem fs = FileSystems.newFileSystem(pack)) {
            return action.run(fs.getPath("/"));
        }
    }

    private static void deleteOutput(Path out) throws IOException {
        if (!Files.exists(out) || !out.getFileName().toString().equals(OUTPUT_NAME)) return;
        List<Path> all;
        try (Stream<Path> s = Files.walk(out)) {
            all = s.sorted(Comparator.reverseOrder()).toList();
        }
        for (Path p : all) Files.deleteIfExists(p);
    }
}
